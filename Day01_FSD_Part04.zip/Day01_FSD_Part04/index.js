const express = require('express');
const port = 8000;
const app = express();
app.use(express.json());
app.use(express.urlencoded({extended:false}));
const router = express.Router();
router.get('/', (request, response)=> response.send('hello from skillsoft'));
router.post('/addemployee', (request, response)=>{
    let empName = request.body.empName;
    let empPass = request.body.empPass;
    response.end(`POST success, you sent ${empName} and ${empPass}, thanks!`);
});
router.get('/aboutus', function(req, res){
	res.send("You are on the about us  route");
});
app.use(router);
//
app.listen(port, function(){
	console.log("Listening " + port);
});

