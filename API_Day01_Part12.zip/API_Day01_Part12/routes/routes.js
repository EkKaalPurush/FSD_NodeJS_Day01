const controller = require('./../controllers/controller');
module.exports = function(router){
    router.get('/', controller.getdefault);
    router.get('/aboutus', controller.aboutus);
    router.post('/addweight', controller.addweight);
    router.get('/getemployees', controller.getemployees);
    router.get('/getemployee/:employeeName', controller.getemployee);
    router.delete('/deletebyname', controller.deletebyname);
    router.post('/addemployee', controller.addemployee);
    router.put('/updateemployee', controller.updateemployee);
}