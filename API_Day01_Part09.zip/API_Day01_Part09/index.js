const express = require('express');
const port = 8000;
const app = express();
const router = express.Router();
app.use(express.json());
app.use(express.urlencoded({extended:false}));
app.use(router);
const routes = require('./routes/routes');
routes(router);
//
app.listen(port, function(){
    console.log("Listening on " + port);
})
