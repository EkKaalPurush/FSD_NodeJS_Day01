module.exports = function(router){
  //
  router.get('/', (request, response)=> response.send('hello from skillsoft'));
  //
  router.post('/addweight', (request, response)=>{
    let empName = request.body.empName;
    let empWeight = request.body.empWeight;
    response.end(`POST success, you sent ${empName} and ${empWeight}, thanks!`);
  });
  //
  router.get('/aboutus', function(req, res){
  	res.send("You are on the about us  route");
  });
};
